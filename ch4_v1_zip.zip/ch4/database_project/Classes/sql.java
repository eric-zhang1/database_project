package Classes;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;


public class sql {
private static PreparedStatement ps;
	
    /**
     * Queries the database and prints the results.
     * 
     * @param conn a connection object
     * @param sql a SQL statement that returns rows:
     * 		this query is written with the Statement class, typically 
     * 		used for static SQL SELECT statements.
     */
    public static void sqlQuery(Connection conn, String sql){
        try {
        	Statement stmt = conn.createStatement();
        	ResultSet rs = stmt.executeQuery(sql);
        	ResultSetMetaData rsmd = rs.getMetaData();
        	int columnCount = rsmd.getColumnCount();
        	for (int i = 1; i <= columnCount; i++) {
        		String value = rsmd.getColumnName(i);
        		System.out.print(value);
        		if (i < columnCount) System.out.print(",  ");
        	}
			System.out.print("\n");
        	while (rs.next()) {
        		for (int i = 1; i <= columnCount; i++) {
        			String columnValue = rs.getString(i);
            		System.out.print(columnValue);
            		if (i < columnCount) System.out.print(",  ");
        		}
    			System.out.print("\n");
        	}
        	rs.close();
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }
    
    
    /**
     * Queries the database and prints the results.
     * 
     * @param conn a connection object
     * @param sql a SQL statement that returns rows:
     * 		this query is written with the PrepareStatement class, typically 
     * 		used for dynamic SQL SELECT statements.
     */
    public static void sqlQuery(Connection conn, PreparedStatement sql){
        try {
        	ResultSet rs = sql.executeQuery();
        	ResultSetMetaData rsmd = rs.getMetaData();
        	int columnCount = rsmd.getColumnCount();
        	for (int i = 1; i <= columnCount; i++) {
        		String value = rsmd.getColumnName(i);
        		System.out.print(value);
        		if (i < columnCount) System.out.print(",  ");
        	}
			System.out.print("\n");
        	while (rs.next()) {
        		for (int i = 1; i <= columnCount; i++) {
        			String columnValue = rs.getString(i);
            		System.out.print(columnValue);
            		if (i < columnCount) System.out.print(",  ");
        		}
    			System.out.print("\n");
        	}
        	rs.close();
        	ps.close();
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }
    
    /**
     * Create PreparedStatement to search a Customer by their user ID.
     * 
     * @param sql query for prepared statement
     * 
     * @param user_ID to search by 
     */
    public static void ps_SearchCustomer(String userID){
    	String sql = "SELECT * FROM Customer WHERE User_ID = ?";
    	try {
    		ps = Main.conn.prepareStatement(sql);
    		ps.setString(1, userID);
    	} catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    	
    	sqlQuery(Main.conn, ps);
    }
    
    /**
     * Create PreparedStatement to search a Warehouse by its warehouse_ID.
     * 
     * @param sql query for prepared statement
     * 
     * @param Warehouse_ID to search by 
     
    public static void ps_SearchWarehouse(String sql, String warehouseID){
    	try {
    		ps = Main.conn.prepareStatement(sql);
    		ps.setString(1, warehouseID);
    	} catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    	
    	sqlQuery(Main.conn, ps);
    }
    
    public static void ps_SearchDrone(String sql, String droneID){
    	try {
    		ps = Main.conn.prepareStatement(sql);
    		ps.setString(1, droneID);
    	} catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    	
    	sqlQuery(Main.conn, ps);
    }
    */
    
    
    public static void addCustomerToDatabase(String userId, String firstName, String lastName, String address, String phone, String email, String startDate, String status) {
        String sql = "INSERT INTO Customer (User_ID, First Name, Last Name, Address, Phone number, Email, Start Date, Status) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";

        try (PreparedStatement ps = Main.conn.prepareStatement(sql)) {
            ps.setString(1, userId);
            ps.setString(2, firstName);
            ps.setString(3, lastName);
            ps.setString(4, address);
            ps.setString(5, phone);
            ps.setString(6, email);
            ps.setString(7, startDate);
            ps.setString(8, status);

            int rowsAffected = ps.executeUpdate();

            if (rowsAffected > 0) {
                System.out.println("Customer added successfully.");
            } else {
                System.out.println("Failed to add Customer.");
            }
        } catch (SQLException e) {
            System.out.println("Error adding customer: " + e.getMessage());
        }
    }
    
    public static void editCustomerToDatabase(String firstName, String lastName, String address, String phone, String email, String status, String userId) {
        String sql = "UPDATE Customer SET First  = ?, Last Name = ?, Address = ?, Phone number = ?, Email = ?, Status = ? WHERE User_ID = ?";

        try (PreparedStatement ps = Main.conn.prepareStatement(sql)) {
            ps.setString(1, userId);
            ps.setString(2, firstName);
            ps.setString(3, lastName);
            ps.setString(4, address);
            ps.setString(5, phone);
            ps.setString(6, email);
            ps.setString(8, status);

            int rowsAffected = ps.executeUpdate();

            if (rowsAffected > 0) {
                System.out.println("Customer added successfully.");
            } else {
                System.out.println("Failed to add Customer.");
            }
        } catch (SQLException e) {
            System.out.println("Error adding customer: " + e.getMessage());
        }
    }
    
    public static void deleteCustomerFromDatabase(String userID){
    	   
    	   String sql = "DELETE FROM CUSTOMER WHERE User_ID = ?";
    	   
    	   try (PreparedStatement ps = Main.conn.prepareStatement(sql)) {
    	              int rowsAffected = ps.executeUpdate();

    	          if (rowsAffected > 0) {
    	              System.out.println("Customer deleted successfully.");
    	          } else {
    	              System.out.println("Failed to delete customer.");
    	          }
    	      } catch (SQLException e) {
    	          System.out.println("Error deleteing customer: " + e.getMessage());
    	      }
    	  }
}
